<?php

namespace PleskExt\Wappspector;

class Helper
{
    public static function getTime(): int
    {
        return time();
    }
}
